#include "cabe�alho.h"
using namespace std;

int main()
{
	//Mudando o c�digo de p�gina para a acentua��o sair normal.
	SetConsoleCP(1252);
	SetConsoleOutputCP(1252);

	ifstream fin;

	unsigned int qnt_prod = 0;
	unsigned int qnt_prodt = 0;

	//Abertura e leitura do arquivo binario de estoque.
	fin.open("estoque.dat", ios_base::binary | ios_base::in);
	fin.read((char*)&qnt_prodt, sizeof(unsigned int));
	fin.read((char*)&qnt_prod, sizeof(unsigned int));

	//Cria��o do vetor din�mico de produto de acordo com a quantidade total de produtos.
	produto* vet = new produto[qnt_prodt];
	fin.read((char*)vet, sizeof(produto) * qnt_prodt);

	//CRIA��O DE UMA VARIAVEL ESTOQUE 
	estoque* estoque_atual = new estoque;
	
	estoque_atual->ptr_p = vet;
	estoque_atual->qntp = qnt_prod;
	estoque_atual->qtotal = qnt_prodt;

	fin.close();

	//PONTEIRO GLOBAL
	estoque* ptr_global = estoque_atual;
	char opcao;

	//La�o principal onde o programa so encerra quando o usuario escolher a op��o SAIR
	do
	{
		//CHAMADA DO MENU
		menu();
		cin >> opcao;
		system("cls");

		//SWITCH PARA A ESCOLHA FEITA PELO MENU
		switch (opcao)
		{
		//PEDIR
		case 'p':
		case 'P': Pedir(ptr_global);
			break;


		//ADICIONAR
		case 'a':
		case 'A': ptr_global = Adicionar(ptr_global);
			break;

		//EXCLUIR
		case 'e':
		case 'E': ptr_global = Excluir(ptr_global);
			break;

		//LISTAR
		case 'l':
		case 'L': Listar(ptr_global);
			break;

		//SAIR
		case 's':
		case 'S': break;
		}

	} while (opcao != 's');

	//GRAVANDO NO ARQUIVO BIN�RIO
	ofstream fout;

	fout.open("estoque.dat", ios_base::binary | ios_base::out);
	fout.write((char*)&ptr_global->qtotal, sizeof(unsigned int));
	fout.write((char*)&ptr_global->qntp, sizeof(unsigned int));
	fout.write((char*)ptr_global->ptr_p, sizeof(produto) * ptr_global->qntp);
	fout.close();


}

