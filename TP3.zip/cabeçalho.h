#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <cmath>
#include <cstring>
#include <Windows.h>
#include <cctype>

using namespace std;

//REGISTRO DE PRODUTO
struct produto
{
	char nome[30];
	double valor;
	int qnt;
};

//REGISTRO DE PEDIDO
struct pedido
{
	char nome[30];
	double valor;
	int qnt;
};

//REGISTRO DE ESTOQUE 
struct estoque
{
	int qntp;
	int qtotal;
	produto* ptr_p;

};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//PROT�TIPO DAS FUN��ES

//Menu com as op��es do programa
void menu(void);

//Listar os produtos do estoque
void Listar(estoque*);

//Fun��o com os procedimentos para realizar o pedido
estoque* Pedir(estoque*);

//Expande o tamanho do estoque e Adiciona um produto nele 
estoque* Adicionar(estoque*);

//Exclui um produto do Estoque
estoque* Excluir(estoque*);

//Fun��o que gera a nota fiscal.
//Utilizada pela fun��o Pedir caso pedido caso ele n�o falhe.
void nota_fiscal(pedido*, int, char*, char*);
