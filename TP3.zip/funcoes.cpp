#include "cabe�alho.h"
using namespace std;

//Fun��o Menu que mostra as op��es do programa para o usu�rio.
void menu(void)
{
	cout << "Sistema de Controle\n";
	cout << "===================\n";
	cout << "(P)edir\n" << "(A)dicionar\n" << "(E)xcluir\n" << "(L)istar\n" << "(S)air\n";
	cout << "===================\n";
	cout << "Opcao: [ ]\b\b";	
}

//Fun��o Pedir, l� um arquivo .txt e confere se os produtos pedidos estao disponivies no estoque.
//Caso esteja gera uma nota fiscal para o cliente com os produtos e o valor total do pedido e o estoque � atualizado.
//Caso contr�rio o pedido falha e o estoque permanece o mesmo sem gerar nota fiscal.
estoque* Pedir(estoque* estoque_atual)
{
	
	cout << "Pedir" << endl;
	cout << "------" << endl;

	//Leitura do nome do arquivo.
	char* arq = new char[100]{ 0 };
	cout << "Arquivo: ";
	cin.ignore();
	cin.getline(arq, 100);

	ifstream fin;
	fin.open(arq);

	//Caso o programa n�o encontre o arquivo com o nome informado.
	if (!fin.is_open())
	{
		cout << endl << "ARQUIVO N�O ENCONTRADO! \n";
	}

	//O programa encontrou o arquivo
	else
	{
		char linha[100] = { 0 };
		int n_produtos = 0;

		//La�o para descobri quantos produtos tem no arquivo texto.
		while (fin.getline(linha, 100))
		{
			n_produtos++;
		}
		fin.close();

		//Ignorando a linha com o nome do cliente e a linha com '-', 
		n_produtos = n_produtos - 2;

		
		//Nova abertura do mesmo arquivo para come�ar a ler as informa��es
		fin.open(arq);

		char nome_cliente[100] = { 0 };
		char* nome_produto = new char[100]{ 0 };
		long double quantidade_produtos = 0;

		fin.getline(nome_cliente, 100);
		fin.getline(linha, 100);

		pedido* vet_prod = new pedido[n_produtos];

		//La�o para ler o nome do produto e a quantidade de acordo com o numero de produtos do arquivo.
		for (int cont = 0; cont < n_produtos; cont++)
		{
			fin >> nome_produto;
			//Formatando o nome do produto lido do arquivo.
			for (int i = 0; i < strlen(nome_produto); i++)
			{
				nome_produto[i] = tolower(nome_produto[i]);

			}

			fin >> quantidade_produtos;
			strcpy(vet_prod[cont].nome, nome_produto);
			vet_prod[cont].qnt = quantidade_produtos;

		}

		//Juntando produtos com o mesmo nome em linhas diferentes
		for (int cont1 = 0; cont1 < n_produtos; cont1++)
		{
			for (int cont2 = 0; cont2 < n_produtos; cont2++)
			{
				if (cont2 == cont1)continue;

				bool cmp = !strcmp(vet_prod[cont1].nome, vet_prod[cont2].nome);

				if (cmp)
				{
					vet_prod[cont2].nome[0] = '\0';

					vet_prod[cont1].qnt += vet_prod[cont2].qnt;
				}

			}
		}
		
		//Vetor de produtos com base no numero de produtos do pedido.
		produto* produtos = new produto[n_produtos];

		int contp = 0;

		//La�os aninhados para passar os valores corretos de acordo com os espa�os do vetor.
		for (int cont1 = 0; cont1 < n_produtos; cont1++)
		{
			if (vet_prod[cont1].nome[0] == '\0')
				continue;

			for (int cont2 = 0; cont2 < estoque_atual->qntp; cont2++)
			{

				bool compair = !strcmp(estoque_atual->ptr_p[cont2].nome, vet_prod[cont1].nome);

				if (compair)
				{
					//Passando os dados
					strcpy(produtos[contp].nome, estoque_atual->ptr_p[cont2].nome);
					produtos[contp].qnt = estoque_atual->ptr_p[cont2].qnt;
					produtos[contp].valor = estoque_atual->ptr_p[cont2].valor;
					contp++;

				}
			}
		}

		//Esse parte pegar os valores dos estoque referentes as produtos ao qual o cliente que 
		//comprar e verifica se o pedido ser realizado

		int situacao_pedido = 0;
	

		cout.precision(2);
		cout << fixed;

		//La�os aninhados para verificar a disponibilidade dos produtos no estoque e consequentmente se o pedido vai falhar ou n�o
		for (int cont1 = 0; cont1 < n_produtos; cont1++)
		{
			int cont_aux = 0;
			if (vet_prod[cont1].nome[0] == '\0')
				continue;


			for (int cont2 = 0; cont2 < contp; cont2++)
			{
				bool result = !strcmp(vet_prod[cont1].nome, produtos[cont2].nome);

				if (result)
				{
					long double operation = produtos[cont2].qnt - vet_prod[cont1].qnt;

					if (operation < 0)
					{
						situacao_pedido++;
						if (situacao_pedido == 1)cout << endl << endl << "Pedido falhou!" << endl << endl;
						cout << vet_prod[cont1].nome << ": " << "Solicitado = " << vet_prod[cont1].qnt
							<< " / " << "Em estoque = " << produtos[cont2].qnt << endl;
					}


				}
				else
				{
					cont_aux++;
					if ((cont_aux) == contp)
					{
						situacao_pedido++;
						if (situacao_pedido == 1)cout << endl << endl << "Pedido falhou!" << endl << endl;
						cout << vet_prod[cont1].nome << ": " << "Solicitado = " << vet_prod[cont1].qnt
							<< " / " << "Em estoque = " << 0.0 << endl;


					}
				}


			}
		}

		//Caso o pedido seja realizado
		if (!situacao_pedido)
		{

			//La�o aninhado que atualiza a quantidade dos produtos no estoque
			for (int cont1 = 0; cont1 < n_produtos; cont1++)
			{
				for (int cont2 = 0; cont2 < estoque_atual->qntp; cont2++)
				{

					bool result = !strcmp(vet_prod[cont1].nome, estoque_atual->ptr_p[cont2].nome);

					if (result)
					{
						estoque_atual->ptr_p[cont2].qnt -= vet_prod[cont1].qnt;
						vet_prod[cont1].valor = estoque_atual->ptr_p[cont2].valor;

					}
				}
			}

			//caso o resultado seja verdadeiro o programa executa a funcao para gerar nota fiscal para o pedido  e atualiza os valores no estoque
			nota_fiscal(vet_prod, n_produtos, arq, nome_cliente);

		}
		
	}
		cout << endl;

		fin.close();
		//Retorna o estoque com as quantidades atualizadas ou n�o caso o pedido falhe.
		return estoque_atual;
}

//Fun��o que gera a nota fiscal, usada pela fun��o Pedir apenas quando o pedido da certo
void nota_fiscal(pedido* pedido_ptr, int tam, char* nome, char* nome_cliente)
{
	
	char notinha[100] = { 0 };

	
	int ch_arq = (strlen(nome) -4) ;
	for (int i = 0; i < ch_arq; i++)
	{
		notinha[i] = nome[i];
	}
	notinha[ch_arq] = '.';
	notinha[ch_arq + 1] = 'n';
	notinha[ch_arq + 2] = 'f';
	notinha[ch_arq + 3] = 'c';


	ofstream fout;
	fout.open(notinha);
	  
	  
	fout << nome_cliente << endl;
	  
	fout << "------------------------------------------------------------" << endl;
	  
	fout.precision(2);
	fout << std::fixed;
	long double total = 0;
	long double valor_individual = 0;

	//La�o para gravar os dados na nota fiscal
	for (int cont = 0; cont < tam; cont++)
	{
		if (pedido_ptr[cont].nome[0] == '\0')
			continue;
		pedido_ptr[cont].nome[0] = toupper(pedido_ptr[cont].nome[0]);

		fout << pedido_ptr[cont].nome << "  ";
		fout << pedido_ptr[cont].qnt << "Kg	  a   ";
		fout << pedido_ptr[cont].valor << "/kg" << "	=   ";

		valor_individual = (pedido_ptr[cont].valor * pedido_ptr[cont].qnt);
		fout << "R$" << valor_individual << endl;

		total += valor_individual;

	}

	fout << "------------------------------------------------------------" << endl;

	//Caso o valor total do pedido ultrapasse os 1000 reais sera aplicado o desonto.
	long double desconto = 0;
	if (total > 1000)
		desconto = (total * 0.1);

	fout << "                       Compra   =   R$" << total << endl;
	fout << "                       Desconto =   R$" << desconto << endl;
	fout << "                       Total	=   R$" << (total - desconto) << endl;


	fout.close();

	cout << endl << "O pedido foi emitido com sucesso!" << endl;

}

//Fun��o Listar que mostra os produtos que est�o no estoque
void Listar(estoque* estoque_atual)
{
	cout << "Listagem" << endl;
	cout << "---------" << endl;

	//Padronizando as saidas com pelo menos duas casas
	cout.precision(2);
	cout << fixed;

	//La�o para a exibi��o dos produtos (nome - valor - quantidade)
	for (int i = 0; i < estoque_atual->qntp; i++)
	{
		cout << estoque_atual->ptr_p[i].nome << " - ";
		cout << "R$" << estoque_atual->ptr_p[i].valor << " - ";
		cout << estoque_atual->ptr_p[i].qnt << " KG\n";
	}
	cout << endl;
}

//A fun��o Excluir apaga um produto selecionado pelo usu�rio do estoque 
estoque* Excluir(estoque* estoque_atual)
{
	cout << "Excluir" << endl;
	cout << "--------" << endl;
	for (int i = 0; i < estoque_atual->qntp; i++)
	{
		cout << i + 1 << " ) " << estoque_atual->ptr_p[i].nome;
		cout << endl;
	}

	int num_prod;
	cout << "N�mero do produto: ";
	cin >> num_prod;
	cout << endl;

	--num_prod;
	char escolha;
	if (num_prod < estoque_atual->qntp && num_prod >= 0 && estoque_atual->qntp != 0)
	{
		cout << "Deseja Excluir " << "\"" << estoque_atual->ptr_p[num_prod].nome << "\"" << "(S/N)? ";
		cin >> escolha;
		escolha = tolower(escolha);


		if (escolha == 's')
		{

			//Vetor de produto com o tamanho reduzido em 1.
			produto* novo_vet = new produto[estoque_atual->qtotal - 1];

			//Copiando os dados dos produtos que vem antes do produto que foi excluido para o novo vetor de produto.
			for (int cont = 0; cont < (num_prod); cont++)
			{
				strcpy(novo_vet[cont].nome, estoque_atual->ptr_p[cont].nome);	    //nome do produto
				novo_vet[cont].valor = estoque_atual->ptr_p[cont].valor;			//valor do produto
				novo_vet[cont].qnt = estoque_atual->ptr_p[cont].qnt;				//quantidade do produto

			}

			//Copiando os dados dos produtos que vem depois do produto que foi excluido para o novo vetor de produto.
			for (int cont = num_prod; cont < estoque_atual->qntp - 1; cont++)
			{
				strcpy(novo_vet[cont].nome, estoque_atual->ptr_p[cont + 1].nome);    //nome do produto
				novo_vet[cont].valor = estoque_atual->ptr_p[cont + 1].valor;		 //valor do produto
				novo_vet[cont].qnt = estoque_atual->ptr_p[cont + 1].qnt;			 //quantidade do produto

			}

			//Cria��o de um novo estoque que ser� retornado ao final da fun��o para substituir o antigo.
			estoque* estoque_reduzido = new estoque;

			estoque_reduzido->ptr_p = novo_vet;
			estoque_reduzido->qntp = estoque_atual->qntp - 1;
			estoque_reduzido->qtotal = estoque_atual->qtotal - 1;

			//Delete do estoque antigo.
			delete[] estoque_atual->ptr_p;
			delete estoque_atual;

			return estoque_reduzido;

		}

		//Caso escolha n�o deletar o produto a fun��o retorna o vetor antigo sem nenhuma altera��o e volta para o menu
		else
		{
			return estoque_atual;
		}

	}
	else 
	{
		//Caso o numero que o usu�rio digite n�o corresponda com nenhuma op��o a fun��o Excluir � chamada novamente
		system("cls");
		return Excluir(estoque_atual);
	}
}

//Fun��o Adicionar, adiciona um produto ao estoque ou sobrescreve caso ja exista um com o mesmo nome
estoque* Adicionar(estoque* estoque_antigo)
{
	//Passando o estoque atual para um novo.
	estoque* estoque_atualizado = estoque_antigo;

	char* nomep = new char[100] {0};
	long double preco;
	long double qnte;

	cout << "Adicionar\n" << "----------\n";
	cin.ignore();

	//Entrada do nome do produto
	cout << "Produto: ";
	cin.getline(nomep, 100);
	//Deixando o nome do produto padronizado
	for (int i = 0; i < strlen(nomep); i++)
	{
		nomep[i] = tolower(nomep[i]);

	}

	//Entrada do valor do Produto
	cout << "Pre�o: ";
	cin >> preco;

	//Entrada da quantidade
	cout << "Quantidade: ";
	cin >> qnte;


	bool str_cmp = 0;
	int find = -1;
	for (int cont = 0; cont < estoque_atualizado->qntp; cont++)
	{
		str_cmp = !strcmp(estoque_atualizado->ptr_p[cont].nome, nomep);
		if (str_cmp) 
		{
			find = cont; 
			break; 
		}
	}

	cout << endl;

	//Caso o nome dos produtos n�o seja igual.
	if (!str_cmp)
	{

		if (estoque_antigo->qtotal == estoque_antigo->qntp)
		{
			//Calculando o tamanho do novo vetor de produto.
			int expansao = sqrt(estoque_antigo->qtotal);
			expansao++;
			expansao = pow(expansao + 1, 2);

			//Novo vetor de produto com a quantidade aumentada em rela��o ao antigo.
			produto* vetor_aumentado = new produto[expansao];

			for (int cont = 0; cont < estoque_antigo->qntp; cont++)
			{
				//Passando os valores.
				strcpy(vetor_aumentado[cont].nome, estoque_antigo->ptr_p[cont].nome);
				vetor_aumentado[cont].qnt = estoque_antigo->ptr_p[cont].qnt;
				vetor_aumentado[cont].valor = estoque_antigo->ptr_p[cont].valor;
			}

			//Novo estoque que ira substituir o antigo ao final da fun��o
			estoque* estoque_at = new estoque;
			
			//Passando os valores
			estoque_at->ptr_p = vetor_aumentado;
			estoque_at->qtotal = expansao;
			estoque_at->qntp = estoque_antigo->qntp;

			//Delete do estoque antingo
			delete[]estoque_antigo->ptr_p;
			delete estoque_antigo;

			estoque_atualizado = estoque_at;



		}

		
		//Passando os valores para o estoque atualizado
		strcpy(estoque_atualizado->ptr_p[estoque_atualizado->qntp].nome, nomep);
		estoque_atualizado->ptr_p[estoque_atualizado->qntp].valor = preco;
		estoque_atualizado->ptr_p[estoque_atualizado->qntp].qnt = qnte;
		estoque_atualizado->qntp++;
	}

	//Caso o nome dos produtos seja igual
	else
	{
		int expansao2 = sqrt(estoque_antigo->qtotal);
		expansao2++;
		expansao2 = pow(expansao2 + 1, 2);

		//Vetor de produtos aumentado
		produto* vetor_expandido = new produto[expansao2];

		for (int cont = 0; cont < estoque_antigo->qntp; cont++)
		{
			//Passando os valores
			strcpy(vetor_expandido[cont].nome, estoque_antigo->ptr_p[cont].nome);
			vetor_expandido[cont].qnt = estoque_antigo->ptr_p[cont].qnt;
			vetor_expandido[cont].valor = estoque_antigo->ptr_p[cont].valor;
		}

		//Novo estoque que substituira o antigo.
		estoque* estoque_at2 = new estoque;


		estoque_at2->ptr_p = vetor_expandido;
		estoque_at2->qtotal = expansao2;
		estoque_at2->qntp = estoque_antigo->qntp;

		//Delete do estoque antigo
		delete[]estoque_antigo->ptr_p;
		delete estoque_antigo;

		estoque_atualizado = estoque_at2;
	
		//Passando os valores
		strcpy(estoque_atualizado->ptr_p[find].nome, nomep);
		estoque_atualizado->ptr_p[find].valor = preco;
		estoque_atualizado->ptr_p[find].qnt = qnte + estoque_at2->ptr_p[find].qnt;

	}
	//Retornando o estoque atualizado
	return estoque_atualizado;
}